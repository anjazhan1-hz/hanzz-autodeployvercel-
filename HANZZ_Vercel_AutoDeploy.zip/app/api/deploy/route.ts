import { NextRequest, NextResponse } from "next/server";
import AdmZip from "adm-zip";
import { createHash } from "crypto";

export const runtime = "nodejs";
export const maxDuration = 60;

function checkPassword(req: NextRequest) {
  const expected = process.env.DASHBOARD_PASSWORD;
  return !expected || req.headers.get("x-dashboard-password") === expected;
}
function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}
function querySuffix() {
  return process.env.VERCEL_TEAM_ID
    ? `?teamId=${encodeURIComponent(process.env.VERCEL_TEAM_ID)}`
    : "";
}

export async function POST(req: NextRequest) {
  if (!checkPassword(req)) return jsonError("Password dashboard salah.", 401);
  const token = process.env.VERCEL_TOKEN;
  const projectId = process.env.VERCEL_PROJECT_ID;
  if (!token || !projectId) return jsonError("Konfigurasi server belum lengkap. Isi VERCEL_TOKEN dan VERCEL_PROJECT_ID di environment variables.", 500);

  try {
    const form = await req.formData();
    const upload = form.get("file");
    if (!(upload instanceof File)) return jsonError("File ZIP tidak ditemukan.");
    if (!upload.name.toLowerCase().endsWith(".zip")) return jsonError("File harus berformat ZIP.");
    if (upload.size > 20 * 1024 * 1024) return jsonError("Ukuran ZIP maksimal 20 MB.");
    const zip = new AdmZip(Buffer.from(await upload.arrayBuffer()));
    const entries = zip.getEntries().filter(e => !e.isDirectory);
    if (!entries.length) return jsonError("ZIP kosong.");
    if (entries.length > 250) return jsonError("Maksimal 250 file dalam satu ZIP.");

    const files: Array<{ file: string; sha: string; size: number }> = [];
    const contentByPath = new Map<string, Buffer>();
    let totalSize = 0;
    for (const entry of entries) {
      const normalized = entry.entryName.replace(/\\/g, "/").replace(/^\.\/+/, "");
      if (!normalized || normalized.startsWith("/") || normalized.split("/").some(p => p === "..") || normalized.includes("\0")) {
        return jsonError("ZIP berisi jalur file yang tidak aman.");
      }
      const content = entry.getData();
      totalSize += content.length;
      if (totalSize > 40 * 1024 * 1024) return jsonError("Total hasil ekstrak maksimal 40 MB.");
      const sha = createHash("sha1").update(content).digest("hex");
      files.push({ file: normalized, sha, size: content.length });
      contentByPath.set(normalized, content);
    }
    const hasIndex = files.some(f => f.file === "index.html") || files.some(f => f.file.endsWith("/index.html"));
    if (!hasIndex) return jsonError("Tidak menemukan index.html. Masukkan index.html di root ZIP, bukan hanya file ZIP di dalam folder lain.");

    // Upload each file by content digest to Vercel.
    for (const item of files) {
      const body = contentByPath.get(item.file)!;
      const uploadRes = await fetch(`https://api.vercel.com/v2/files${querySuffix()}`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/octet-stream",
          "Content-Length": String(body.length),
          "x-vercel-digest": item.sha
        },
        body
      });
      if (!uploadRes.ok && uploadRes.status !== 409) {
        const detail = await uploadRes.text();
        return jsonError(`Gagal mengunggah ${item.file} ke Vercel (${uploadRes.status}): ${detail.slice(0, 300)}`, 502);
      }
    }

    const deployBody = {
      name: process.env.VERCEL_PROJECT_NAME || "hanzz-site",
      project: projectId,
      projectId,
      target: "production",
      files: files.map(f => ({ file: f.file, sha: f.sha, size: f.size })),
      projectSettings: { framework: null }
    };
    const createRes = await fetch(`https://api.vercel.com/v13/deployments${querySuffix()}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(deployBody)
    });
    const result = await createRes.json().catch(() => ({}));
    if (!createRes.ok) return jsonError(`Vercel menolak deployment (${createRes.status}): ${result.error?.message || JSON.stringify(result).slice(0, 500)}`, 502);
    return NextResponse.json({
      message: "Deployment dibuat. Vercel sedang memproses file website.",
      deployment: {
        uid: result.id || result.uid,
        id: result.id || result.uid,
        name: result.name || deployBody.name,
        url: result.url,
        state: result.readyState || result.state || "QUEUED",
        readyState: result.readyState || result.state || "QUEUED",
        target: result.target || "production",
        inspectorUrl: result.inspectorUrl
      }
    });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Gagal memproses ZIP.", 500);
  }
}