import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const expected = process.env.DASHBOARD_PASSWORD;
  if (expected && req.headers.get("x-dashboard-password") !== expected) {
    return NextResponse.json({ error: "Password dashboard salah." }, { status: 401 });
  }
  const token = process.env.VERCEL_TOKEN;
  const projectId = process.env.VERCEL_PROJECT_ID;
  if (!token || !projectId) {
    return NextResponse.json({ error: "Isi VERCEL_TOKEN dan VERCEL_PROJECT_ID terlebih dahulu." }, { status: 500 });
  }
  const team = process.env.VERCEL_TEAM_ID ? `&teamId=${encodeURIComponent(process.env.VERCEL_TEAM_ID)}` : "";
  const res = await fetch(`https://api.vercel.com/v6/deployments?projectId=${encodeURIComponent(projectId)}&limit=10${team}`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store"
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return NextResponse.json({ error: data.error?.message || "Gagal mengambil data deployment Vercel." }, { status: res.status });
  const deployments = (data.deployments || []).map((d: any) => ({
    uid: d.uid,
    id: d.uid,
    name: d.name,
    url: d.url,
    state: d.state,
    readyState: d.readyState || d.state,
    createdAt: d.createdAt,
    target: d.target,
    inspectorUrl: d.inspectorUrl
  }));
  return NextResponse.json({ deployments });
}