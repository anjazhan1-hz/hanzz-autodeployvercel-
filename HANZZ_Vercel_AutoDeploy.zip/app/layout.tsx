import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HANZZ Deploy | Vercel Dashboard",
  description: "Dashboard deploy ZIP statis ke Vercel.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}