 "use client";

import { useEffect, useRef, useState } from "react";

type Deployment = {
  uid?: string;
  id?: string;
  name?: string;
  url?: string;
  state?: string;
  readyState?: string;
  createdAt?: number;
  target?: string;
  inspectorUrl?: string;
};

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("Siap menerima ZIP website statis.");
  const [deployment, setDeployment] = useState<Deployment | null>(null);
  const [history, setHistory] = useState<Deployment[]>([]);
  const [checking, setChecking] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function deploy() {
    if (!file) { setMessage("Pilih file ZIP terlebih dahulu."); return; }
    if (!file.name.toLowerCase().endsWith(".zip")) { setMessage("File harus berformat .zip."); return; }
    setBusy(true); setMessage("Mengunggah dan membuat deployment…"); setDeployment(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/deploy", {
        method: "POST",
        headers: password ? { "x-dashboard-password": password } : {},
        body: form
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Deployment gagal.");
      setDeployment(data.deployment);
      setMessage(data.message || "Permintaan deployment berhasil dikirim.");
      loadHistory();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Terjadi kesalahan.");
    } finally { setBusy(false); }
  }

  async function loadHistory() {
    setChecking(true);
    try {
      const res = await fetch("/api/deployments", { headers: password ? { "x-dashboard-password": password } : {} });
      const data = await res.json();
      if (res.ok) setHistory(data.deployments || []);
      else setMessage(data.error || "Tidak bisa mengambil status.");
    } catch { setMessage("Tidak bisa menghubungi API status."); }
    finally { setChecking(false); }
  }

  useEffect(() => { loadHistory(); /* initial list */ }, []);

  const currentState = deployment?.readyState || deployment?.state || "QUEUED";
  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#"><span className="brandMark">H</span><span>HANZZ<span className="brandThin"> DEPLOY</span></span></a>
        <span className="topPill"><i /> VERCEL CONTROL CENTER</span>
      </header>

      <section className="hero">
        <div className="eyebrow"><span className="spark">✦</span> SIMPLE DEPLOYMENT WORKSPACE</div>
        <h1>Deploy website.<br /><em>Tanpa ribet.</em></h1>
        <p className="heroText">Upload ZIP website statis, kirim deployment ke Vercel, lalu pantau statusnya dari satu dashboard.</p>
        <div className="heroMeta"><span><b>01</b> Upload ZIP</span><span><b>02</b> Deploy</span><span><b>03</b> Monitor</span></div>
      </section>

      <section className="grid">
        <article className="panel uploadPanel">
          <div className="panelHead"><div><div className="overline">NEW DEPLOYMENT</div><h2>Upload project</h2></div><span className="step">01 / 03</span></div>
          <button className={`dropzone ${file ? "hasFile" : ""}`} onClick={() => inputRef.current?.click()} type="button" disabled={busy}>
            <input ref={inputRef} type="file" accept=".zip,application/zip" hidden onChange={e => setFile(e.target.files?.[0] || null)} />
            <span className="uploadIcon">↑</span>
            <strong>{file ? file.name : "Pilih file ZIP website"}</strong>
            <span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · siap dikirim` : "Klik untuk memilih · ZIP saja"}</span>
            <small>Pastikan index.html berada di root ZIP atau di folder utama yang dikenali.</small>
          </button>
          <label className="fieldLabel" htmlFor="pass">Dashboard password <span>(opsional)</span></label>
          <input id="pass" className="textInput" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Isi jika DASHBOARD_PASSWORD diatur" autoComplete="current-password" />
          <button className="primaryBtn" onClick={deploy} disabled={busy || !file}>{busy ? <><span className="spinner" /> Mengirim deployment…</> : <>Deploy ke Vercel <span>↗</span></>}</button>
          <div className="notice"><span>ⓘ</span><p>Versi ini untuk website statis HTML/CSS/JS. Project Next.js, Vite yang perlu build, atau backend perlu alur build terpisah.</p></div>
        </article>

        <article className="panel statusPanel">
          <div className="panelHead"><div><div className="overline">DEPLOYMENT STATUS</div><h2>Ringkasan</h2></div><span className="live"><i /> LIVE DATA</span></div>
          <div className="statusCard">
            <div className="statusTop"><span className="statusOrb">↗</span><span className={`state ${String(currentState).toUpperCase()}`}>{String(currentState).replaceAll("_", " ")}</span></div>
            <div className="statusTitle">{deployment ? (deployment.name || "Deployment terbaru") : "Belum ada deployment baru"}</div>
            <p>{deployment ? "Permintaan deployment sudah diterima oleh Vercel." : "Deployment yang baru kamu kirim akan muncul di sini."}</p>
            {deployment?.url && <a className="siteLink" href={`https://${deployment.url}`} target="_blank" rel="noreferrer">Buka website <span>↗</span></a>}
            {deployment?.inspectorUrl && <a className="inspectLink" href={deployment.inspectorUrl} target="_blank" rel="noreferrer">Buka detail deployment di Vercel</a>}
          </div>
          <div className="messageBox"><span className="messageDot" /> <span>{message}</span></div>
          <button className="secondaryBtn" onClick={loadHistory} disabled={checking}>{checking ? "Memuat…" : "↻  Refresh status"}</button>
        </article>
      </section>

      <section className="panel historyPanel">
        <div className="panelHead"><div><div className="overline">ACTIVITY</div><h2>Deployment terbaru</h2></div><span className="historyCount">{history.length} item</span></div>
        {history.length ? <div className="historyList">{history.map((d, i) => {
          const state = d.readyState || d.state || "UNKNOWN";
          return <div className="historyItem" key={d.uid || d.id || i}>
            <span className={`historyIcon ${String(state).toUpperCase() === "READY" ? "ready" : ""}`}>{String(state).toUpperCase() === "READY" ? "✓" : "↗"}</span>
            <div className="historyInfo"><strong>{d.name || "Vercel deployment"}</strong><span>{d.createdAt ? new Date(d.createdAt).toLocaleString("id-ID") : "Waktu tidak tersedia"} · {d.target || "preview"}</span></div>
            <span className={`state small ${String(state).toUpperCase()}`}>{String(state).replaceAll("_", " ")}</span>
            {d.url && <a className="rowLink" href={`https://${d.url}`} target="_blank" rel="noreferrer">Buka ↗</a>}
          </div>;
        })}</div> : <div className="emptyState"><span>◷</span><strong>Belum ada data</strong><p>Setelah konfigurasi Vercel benar, daftar deployment akan tampil di sini.</p></div>}
      </section>

      <footer><span>HANZZ DEPLOY <b>•</b> BUILT FOR VERCEL</span><span>Token disimpan di server, bukan di browser.</span></footer>
    </main>
  );
}