# HANZZ Deploy — Vercel Dashboard

Dashboard dark merah untuk mengirim **website statis HTML/CSS/JS** dari ZIP ke Vercel dan melihat 10 deployment terakhir.

## Fitur
- Upload ZIP melalui dashboard
- Kirim file ke Vercel API dan buat deployment production
- Daftar deployment terbaru, status, waktu, dan tautan website
- Token Vercel hanya dibaca di server lewat environment variables
- Batas dasar upload: ZIP 20 MB, hasil ekstrak 40 MB, 250 file

> Penting: versi ini ditujukan untuk ZIP website statis yang memiliki `index.html`. Ini tidak menjalankan `npm install` atau build untuk project Next.js/Vite. Untuk framework tersebut gunakan integrasi GitHub → Vercel atau buat pipeline build terpisah.

## 1. Siapkan Vercel
1. Login ke https://vercel.com/
2. Buat atau pilih project Vercel untuk website yang akan di-deploy.
3. Buka **Project Settings → General** dan salin **Project ID**.
4. Buka https://vercel.com/account/tokens lalu buat token. Beri akses seminimal mungkin sesuai project/akun.
5. Jangan pernah mengirim token ke orang lain atau menaruhnya di file frontend.

## 2. Jalankan lokal
Perlu Node.js 20 atau lebih baru.
```bash
npm install
cp .env.example .env.local
```
Buka `.env.local`, isi:
```env
VERCEL_TOKEN=token_rahasia_kamu
VERCEL_PROJECT_ID=prj_id_project_kamu
# Opsional bila project ada di team:
# VERCEL_TEAM_ID=team_id_kamu
# Sangat disarankan bila dashboard akan diakses publik:
DASHBOARD_PASSWORD=password-panjang-yang-sulit-ditebak
```
Lalu jalankan:
```bash
npm run dev
```
Buka http://localhost:3000

## 3. Format ZIP
ZIP harus berisi file website siap pakai, misalnya:
```
website.zip
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── images/
    └── logo.png
```
Hindari membungkus semua file di folder tambahan bila bisa. `index.html` harus ada di root ZIP. Jangan masukkan `node_modules`, `.env`, token, atau file rahasia.

## 4. Deploy dashboard ini ke Vercel
1. Buat repository GitHub baru dan upload semua file project ini.
2. Di Vercel, pilih **Add New → Project**, impor repository tersebut.
3. Di **Project Settings → Environment Variables**, tambahkan `VERCEL_TOKEN`, `VERCEL_PROJECT_ID`, dan opsional `VERCEL_TEAM_ID` serta `DASHBOARD_PASSWORD`.
4. Klik Deploy. Setelah deployment dashboard berhasil, buka URL-nya.
5. Setelah mengubah environment variables, lakukan redeploy agar perubahan berlaku.

### Penting soal keamanan
- Jangan commit `.env.local` ke GitHub.
- Kalau dashboard akan online untuk orang lain, set `DASHBOARD_PASSWORD` yang kuat. Untuk aplikasi multi-user, ganti password sederhana ini dengan autentikasi yang proper dan batasi siapa yang boleh deploy.
- Token punya kuasa terhadap akun/project sesuai akses yang diberikan. Jika token bocor, revoke segera dari pengaturan Vercel.
- Endpoint ini membuat deployment **production** ke project yang kamu konfigurasi. Tes dulu dengan project percobaan.
- API Vercel atau batasan akun dapat berubah; jika API mengembalikan error, baca pesan di dashboard dan cek detail deployment di Vercel.

## Struktur
- `app/page.tsx` — dashboard UI
- `app/api/deploy/route.ts` — ZIP upload dan create deployment
- `app/api/deployments/route.ts` — ambil daftar status
- `app/globals.css` — desain hitam-merah
- `.env.example` — template konfigurasi (bukan token asli)
